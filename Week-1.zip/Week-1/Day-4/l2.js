function valform()
{
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if(username==""){alert("Please enter the Username");return false;}
    if(password=="") {alert("Please enter the Password");return false;}
    else {alert("Welcome user");}
    window.location.href="file:///C:/Users/RCC/Desktop/Hari/Website/main.html"; return false;
    }