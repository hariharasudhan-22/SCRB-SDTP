function validateform()
{
    var username=document.getElementById("username").value;
    var password=document.getElementById("password").value;
    if(username==""){alert("Please enter the Username");return false;}
    if(password=="") {alert("Please enter the Password");return false;}
}